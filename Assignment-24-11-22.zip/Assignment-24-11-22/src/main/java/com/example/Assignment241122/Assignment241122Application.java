package com.example.Assignment241122;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment241122Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment241122Application.class, args);
	}

}
